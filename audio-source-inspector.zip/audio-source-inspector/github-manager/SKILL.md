---
name: github-manager
description: Manage GitHub repositories, files, issues and pull requests through the connected GitHub account. Use when the user asks to create a repo, upload or update files in a repo, open or update issues or PRs, review PR diffs, check CI status, or inspect a user's repositories.
---

# GitHub Manager

## Before acting
1. Call `get_me` to confirm which account is connected and use its `login` as the default owner.
2. If the user did not name a repo, ask which one. Do not guess.
3. Prefer reading first (`get_file_contents`, `list_*`, `pull_request_read`) before any write.

## Repositories
- Create: `create_repository` with `name`, `description`, and `private` (default to private unless the user asks for public).
- If creation returns 403 "Resource not accessible by integration", the app lacks Administration permission. Tell the user to grant it under GitHub Settings → Applications → Installed GitHub Apps, or to create an empty repo manually.
- Set `autoInit: true` if the repo needs a `main` branch before the first file upload.

## Files
- Create or update: `create_or_update_file` with `owner`, `repo`, `path`, `branch`, `content`, `message`.
- For an existing file, first read it with `get_file_contents` to get its `sha`, then pass that `sha`. Without it the write fails.
- Commit messages should be short and describe the change (e.g., "Add README").
- Content is sent as plain text. Do not base64-encode it.

## Issues and pull requests
- Issues: `issue_write` with `method: create` or `update`.
- PRs: `create_pull_request`, `update_pull_request`; read with `pull_request_read` (`get`, `get_files`, `get_diff`, `get_check_runs`).
- Review: `pull_request_review_write` with `create`, then `submit_pending` or direct `event` (APPROVE, REQUEST_CHANGES, COMMENT).
- Never approve or merge without explicit user instruction.

## Safety
- Confirm before deleting files, closing issues/PRs, or changing repo visibility.
- Never print tokens or secrets. If a file contains an apparent secret, warn the user and do not commit it.
- Report the resulting URL after each successful write.

## Response style
Keep replies short: what was done, the link, and any next step. Reply in the user's language.
